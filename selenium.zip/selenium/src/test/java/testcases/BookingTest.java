package testcases;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.FlightDetailsPage;
import pages.HomePage;
import pages.SearchPage;

public class BookingTest {
	
	WebDriver driver;
	
	@BeforeTest
	@Parameters({"browserName"})
	public void setUp(String browserName)
	{
		if(browserName.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
		}
	}
	
	@Test
	public void booking()
	{
		driver.get("https://www.orbitz.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		HomePage homepage=new HomePage(driver);
		homepage.flights_menu.click();
		homepage.leaving_from_menu.click();
		homepage.leaving_from_field.sendKeys("San Francisco");
		List<WebElement> airports=driver.findElements(By.xpath("//div[@class='truncate']/span"));
		for(int i=0;i<airports.size();i++)
		{
			if(airports.get(i).getText().contains("San Francisco"))
			{
				airports.get(i).click();
				break;
			}
		}
		homepage.going_to_menu.click();
		homepage.going_to_field.sendKeys("New York");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		List<WebElement> destinationairports=driver.findElements(By.xpath("//div[@class='truncate']/span/strong"));
		for(int i=0;i<destinationairports.size();i++)
		{
			if(destinationairports.get(i).getText().contains("New York"))
			{
				destinationairports.get(i).click();
				break;
			}
		}
		
		homepage.departing_date_icon.click();
		SimpleDateFormat myFormat = new SimpleDateFormat("MMM dd, yyyy");
		String departing_date = null;
		String returning_date = null;
		List<WebElement> departingdates=driver.findElements(By.xpath("//button[@class='uitk-date-picker-day uitk-new-date-picker-day']"));
		for(int i=0;i<departingdates.size();i++)
		{
			try {
			    Date date2 = myFormat.parse(departingdates.get(i).getAttribute("aria-label"));
			    long diff = date2.getTime() - new Date().getTime();
			    //System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
			    long days=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			    if(days==12)
			    {
			    	departingdates.get(i).click();
			    	departing_date=departingdates.get(i).getAttribute("aria-label");
			    	homepage.done_button.click();
			    	break;
			    }
			    
			} catch (ParseException e) {
			    e.printStackTrace();
			}
				
			
		}
		
		homepage.returning_date_icon.click();
		List<WebElement> dates=driver.findElements(By.xpath("//button[@class='uitk-date-picker-day uitk-new-date-picker-day']"));
		for(int i=0;i<dates.size();i++)
		{
			try {
			    Date date2 = myFormat.parse(dates.get(i).getAttribute("aria-label"));
			    long diff = date2.getTime() - new Date().getTime();
			    //System.out.println ("Days: " + TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));
			    long days=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			    if(days==19)
			    {
			    	dates.get(i).click();
			    	returning_date=dates.get(i).getAttribute("aria-label");
			    	homepage.done_button.click();
			    	break;
			    }
			    
			} catch (ParseException e) {
			    e.printStackTrace();
			}
				
			
		}
		
		homepage.search_button.click();
		SearchPage searchpage=new SearchPage(driver);
		Assert.assertTrue(searchpage.flying_from.getText().contains("San Francisco"));
		Assert.assertTrue(searchpage.flying_to.getText().contains("New York"));
		Assert.assertTrue(departing_date.contains(searchpage.departing_date.getText()));
		Assert.assertTrue(returning_date.contains(searchpage.returning_date.getText()));
		
		searchpage.non_stop_checkbox.click();
		Select price=new Select(searchpage.sort_by_dropdown);
		price.selectByVisibleText("Price (Highest)");
		searchpage.flight_select.click();
		searchpage.continue_button.click();
		WebDriverWait wait=new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(searchpage.flight_select));
		if(searchpage.non_stop_checkbox.isEnabled())
		searchpage.non_stop_checkbox.click();
		String total_price="";
		if(searchpage.sort_by_dropdown.isEnabled())
		{
		Select price1=new Select(searchpage.sort_by_dropdown);
		price1.selectByVisibleText("Price (Highest)");
		total_price=searchpage.flight_select.getText();
		}
		searchpage.flight_select.click();
		searchpage.continue_button.click();
		
		for(String handle:driver.getWindowHandles())
		{
			driver.switchTo().window(handle);
		}
		
		FlightDetailsPage flightdetails=new FlightDetailsPage(driver);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(FlightDetailsPage.TOTAL_PRICE)));
		Assert.assertTrue(flightdetails.departing_details.getText().contains("San Francisco to New York"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", flightdetails.returning_details);
		Assert.assertTrue(flightdetails.returning_details.getText().contains("New York to San Francisco"));
		Assert.assertTrue(total_price.contains(flightdetails.total_price.getText()));
		
		

	}
	
	@AfterTest
	public void tearDown()
	{
		driver.quit();
	}

}
