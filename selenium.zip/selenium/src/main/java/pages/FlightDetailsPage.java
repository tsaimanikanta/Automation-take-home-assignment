package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import constants.FlightDetailsConstants;

public class FlightDetailsPage extends FlightDetailsConstants {
	
	@FindBy(xpath=DEPARTING_DETAILS)
	public WebElement departing_details;
	
	@FindBy(xpath=RETURNING_DETAILS)
	public WebElement returning_details;
	
	@FindBy(xpath=TOTAL_PRICE)
	public WebElement total_price;
	
	
	public FlightDetailsPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}

}
