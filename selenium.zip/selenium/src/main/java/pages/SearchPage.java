package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import constants.SearchPageConstants;

public class SearchPage extends SearchPageConstants {
	
	@FindBy(id=NON_STOP_CHECKBOX)
	public WebElement non_stop_checkbox;
	
	@FindBy(xpath=SORT_BY_DROPDOWN)
	public WebElement sort_by_dropdown;
	
	@FindBy(id=DEPARTING_DATE)
	public WebElement departing_date;
	
	@FindBy(id=RETURNING_DATE)
	public WebElement returning_date;
	
	@FindBy(xpath=FLIGHT_SELECT)
	public WebElement flight_select;
	
	@FindBy(xpath=CONTINUE_BUTTON)
	public WebElement continue_button;
	
	@FindBy(xpath=FLYING_FROM)
	public WebElement flying_from;
	
	@FindBy(xpath=FLYING_TO)
	public WebElement flying_to;
	
	
	public SearchPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
}
