package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import constants.HomePageConstants;

public class HomePage extends HomePageConstants {
	
	@FindBy(xpath=FLIGHTS)
	public WebElement flights_menu;
	
	@FindBy(id=LEAVING_FROM)
	public WebElement leaving_from_menu;
	
	@FindBy(id=LEAVING_FROM_FIELD)
	public WebElement leaving_from_field;
	
	@FindBy(id=GOING_TO)
	public WebElement going_to_menu;
	
	@FindBy(id=GOING_TO_FIELD)
	public WebElement going_to_field;
	
	@FindBy(xpath=DEPARTING_DATE)
	public WebElement departing_date;
	
	@FindBy(xpath=RETURNING_DATE)
	public WebElement returning_date;
	
	@FindBy(id=DEPARTING_DATE_ICON)
	public WebElement departing_date_icon;
	
	@FindBy(id=RETURNING_DATE_ICON)
	public WebElement returning_date_icon;
	
	@FindBy(xpath=SEARCH_BUTTON)
	public WebElement search_button;
	
	@FindBy(xpath=AIRPORTS_LIST)
	public WebElement airports_list;
	
	@FindBy(xpath=DONE_BUTTON)
	public WebElement done_button;
	
	
	public HomePage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	

}