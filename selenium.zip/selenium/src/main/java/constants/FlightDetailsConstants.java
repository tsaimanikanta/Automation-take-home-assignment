package constants;

public class FlightDetailsConstants {
	public static final String DEPARTING_DETAILS="//div[@data-test-id='flight-review-0']/div[1]/h2"; //xpath
	public static final String RETURNING_DETAILS="//div[@data-test-id='flight-review-header']/div[1]/following::h2[1]"; //xpath
	public static final String TOTAL_PRICE="//table[@data-test-id='price-summary-travelers-1']/following::table/tbody/tr/td[2]/span"; //xpath
}
