package constants;

public class SearchPageConstants {
	public static final String NON_STOP_CHECKBOX="stops-0"; //id
	public static final String SORT_BY_DROPDOWN="//select[@data-test-id='sortDropdown']"; //xpath
	public static final String DEPARTING_DATE="start-date-ROUND_TRIP-0-btn"; //id
	public static final String RETURNING_DATE="end-date-ROUND_TRIP-0-btn"; //id
	public static final String FLIGHT_SELECT="//button[@data-test-id='select-link']"; //xpath
	public static final String CONTINUE_BUTTON="//button[@data-test-id='select-button']"; //xpath
	public static final String FLYING_FROM="//button[@data-stid='typeahead-originInput-0-menu-trigger']"; //xpath
	public static final String FLYING_TO="//button[@data-stid='typeahead-destinationInput-0-menu-trigger']"; //xpath
	
}
