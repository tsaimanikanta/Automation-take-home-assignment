package constants;

public class HomePageConstants {
	public static final String FLIGHTS="//span[contains(text(),'Flights')]";
	public static final String LEAVING_FROM="location-field-leg1-origin-menu";
	public static final String LEAVING_FROM_FIELD="location-field-leg1-origin";
	public static final String AIRPORTS_LIST="//div[@class='truncate']/span/strong";
	public static final String GOING_TO="location-field-leg1-destination-menu";
	public static final String GOING_TO_FIELD="location-field-leg1-destination";
	public static final String DEPARTING_DATE_ICON="d1-btn";
	public static final String DEPARTING_DATE="//button[@class='uitk-date-picker-day uitk-new-date-picker-day']";
	public static final String RETURNING_DATE_ICON="d2-btn";
	public static final String DONE_BUTTON="//span[contains(text(),'Done')]";
	public static final String RETURNING_DATE="//button[@class='uitk-date-picker-day uitk-new-date-picker-day']";
	public static final String SEARCH_BUTTON="//button[@data-testid='submit-button']";
	

}
